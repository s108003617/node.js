export default [
  {
    name: "Bill",
    age: 28,
    id: "A001",
  },
  {
    name: "Peter",
    age: 32,
    id: "A002",
  },
  {
    name: "Carl",
    age: 29,
    id: "A003",
  },
];
