const f = (a) => a * a;

console.log(f(6));